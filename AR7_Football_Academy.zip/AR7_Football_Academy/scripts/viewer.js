let currentIndex = 0;
const slides = document.querySelectorAll(".slider-image");

function moveSlide(direction) {
  currentIndex += direction;

  // التأكد من أن المؤشر لا يتجاوز حدود الصور
  if (currentIndex < 0) {
    currentIndex = slides.length - 1; // العودة إلى آخر صورة
  } else if (currentIndex >= slides.length) {
    currentIndex = 0; // العودة إلى أول صورة
  }

  // تحريك العرض إلى الصورة المناسبة
  const sliderContainer = document.querySelector(".slider-container");
  sliderContainer.style.transform = `translateX(-${currentIndex * 100}%)`;
}